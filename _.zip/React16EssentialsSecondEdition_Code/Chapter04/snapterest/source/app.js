import React from 'react';
import ReactDOM from 'react-dom';
import StatefulComponent from './components/StatefulComponent';

ReactDOM.render(
  <div>
    <StatefulComponent/>
  </div>,
  document.getElementById('react-application')
);
